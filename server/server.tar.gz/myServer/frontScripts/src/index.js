document.querySelector('div.lego').addEventListener('click', (e) => {
  location.href = location.origin + '/lego'
})
document.querySelector('div.blog').addEventListener('click', (e) => {
  location.href = location.origin + '/blog'
})
